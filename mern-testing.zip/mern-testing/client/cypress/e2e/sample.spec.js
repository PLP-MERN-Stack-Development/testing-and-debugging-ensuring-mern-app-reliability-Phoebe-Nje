describe("MERN App E2E", () => {
  it("Visits the app and checks heading", () => {
    cy.visit("http://localhost:3000");
    cy.contains("MERN Testing Assignment");
  });
});