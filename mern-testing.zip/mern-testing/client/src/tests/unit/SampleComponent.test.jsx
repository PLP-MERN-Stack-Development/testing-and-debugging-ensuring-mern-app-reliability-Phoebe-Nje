import { render, screen } from "@testing-library/react";
import SampleComponent from "../../components/SampleComponent";

test("renders SampleComponent with text", () => {
  render(<SampleComponent text="Hello" />);
  expect(screen.getByText("Hello")).toBeInTheDocument();
});