import React from "react";

const SampleComponent = ({ text }) => {
  return <p>{text}</p>;
};

export default SampleComponent;