const request = require("supertest");
const app = require("../../src/index");

describe("API Integration", () => {
  it("GET /api/health works", async () => {
    const res = await request(app).get("/api/health");
    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe("ok");
  });
});